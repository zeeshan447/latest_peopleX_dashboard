# step-wizard-react
How to create step wizard in React

## Documentation

[https://www.cluemediator.com/how-to-create-step-wizard-in-react](https://www.cluemediator.com/how-to-create-step-wizard-in-react)

## Quick Start

Follow the below steps to run the project.

1. Clone repository
2. Run `npm i` command to install dependencies
3. Execute `npm start` command to run the project

## Connect with us

Website: [Clue Mediator](https://www.cluemediator.com)  
Like us on [Facebook](https://www.facebook.com/thecluemediator)  
Follow us on [Twitter](https://twitter.com/cluemediator)
Follow us on [Telegram](https://t.me/cluemediator)
